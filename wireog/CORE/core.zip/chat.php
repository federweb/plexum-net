<?php
session_start();
header('Content-Type: application/json');

require_once __DIR__ . '/../../room_auth.php';

$messagesFile = 'messages.json';
$usersFile = 'users.json';
$roomAccessFile = 'room_access.json';
$audioDirectory = 'audio_messages/';
$uploadDirectory = 'upload_files/';

$currentDate = date('d/m/Y, H:i');

if (!file_exists($uploadDirectory)) {
    mkdir($uploadDirectory, 0777, true);
    file_put_contents($uploadDirectory . '/index.php', 'Vi veri universum vivus vici');
}
if (!file_exists($audioDirectory)) {
    mkdir($audioDirectory, 0777, true);
    file_put_contents($audioDirectory . '/index.php', 'Vi veri universum vivus vici');
}


function getCurrentRoomId() {
    $scriptPath = $_SERVER['SCRIPT_NAME'];
    $pathParts = explode('/', trim($scriptPath, '/'));
    array_pop($pathParts);
    return end($pathParts) ?: 'default';
}


$roomId = getCurrentRoomId();



// Messages are stored one JSON object per line (JSON Lines), not as a
// single JSON array, so a new message can be appended to the file
// without ever reading or rewriting the messages that came before it.
function loadMessages() {
    global $messagesFile;

    if (!file_exists($messagesFile)) {
        return [];
    }

    $fp = fopen($messagesFile, 'r');
    if (!$fp) {
        return [];
    }

    $messages = [];
    if (flock($fp, LOCK_SH)) {
        while (($line = fgets($fp)) !== false) {
            $line = trim($line);
            if ($line === '') {
                continue;
            }
            $decoded = json_decode($line, true);
            if (is_array($decoded)) {
                $messages[] = $decoded;
            }
        }
        flock($fp, LOCK_UN);
    }
    fclose($fp);

    return $messages;
}

// Reads only the last line of the file (seeking backward in chunks)
// instead of the whole thing, so computing the next message id stays
// cheap no matter how long the chat history is.
function getLastJsonLine($fp) {
    fseek($fp, 0, SEEK_END);
    $pos = ftell($fp);
    if ($pos === 0) {
        return null;
    }

    $chunkSize = 4096;
    $buffer = '';

    while ($pos > 0) {
        $readSize = min($chunkSize, $pos);
        $pos -= $readSize;
        fseek($fp, $pos);
        $buffer = fread($fp, $readSize) . $buffer;

        $trimmed = rtrim($buffer, "\n");
        $newlinePos = strrpos($trimmed, "\n");
        if ($newlinePos !== false) {
            return substr($trimmed, $newlinePos + 1);
        }
        if ($pos === 0) {
            return $trimmed;
        }
    }

    return null;
}

// Full rewrite of the file, used only by /deleteall to truncate the
// history back down to the welcome messages. Locks the real file (not
// a temp copy) so it can never race with a concurrent appendMessage().
function writeAllMessages($messages) {
    global $messagesFile;

    $fp = fopen($messagesFile, 'c+');
    if (!$fp) {
        return false;
    }

    if (!flock($fp, LOCK_EX)) {
        fclose($fp);
        return false;
    }

    $lines = array_map('json_encode', $messages);
    $content = $lines ? implode("\n", $lines) . "\n" : '';

    ftruncate($fp, 0);
    rewind($fp);
    $bytesWritten = fwrite($fp, $content);
    fflush($fp);
    flock($fp, LOCK_UN);
    fclose($fp);

    return $bytesWritten === strlen($content);
}

function loadUsers() {
    global $usersFile;
    if (!file_exists($usersFile)) {
        return [];
    }

    $fp = fopen($usersFile, 'r');
    if (!$fp) {
        return [];
    }

    if (flock($fp, LOCK_SH)) {
        $content = '';
        while (!feof($fp)) {
            $content .= fread($fp, 8192);
        }
        flock($fp, LOCK_UN);
        fclose($fp);

        $decoded = json_decode($content, true);
        return $decoded ? $decoded : [];
    } else {
        fclose($fp);
        return [];
    }
}

function saveUsers($users) {
    global $usersFile;

    $tempFile = $usersFile . '.tmp.' . uniqid();
    $content = json_encode($users);

    $fp = fopen($tempFile, 'w');
    if (!$fp) {
        return false;
    }

    if (flock($fp, LOCK_EX)) {
        $bytesWritten = fwrite($fp, $content);
        fflush($fp);
        flock($fp, LOCK_UN);
        fclose($fp);

        if ($bytesWritten === strlen($content)) {
            if (rename($tempFile, $usersFile)) {
                return true;
            }
        }
    } else {
        fclose($fp);
    }

    if (file_exists($tempFile)) {
        unlink($tempFile);
    }
    return false;
}

function loadRoomAccess() {
    global $roomAccessFile;
    if (!file_exists($roomAccessFile)) {
        return ['blocked' => false];
    }

    $fp = fopen($roomAccessFile, 'r');
    if (!$fp) {
        return ['blocked' => false];
    }

    if (flock($fp, LOCK_SH)) {
        $content = '';
        while (!feof($fp)) {
            $content .= fread($fp, 8192);
        }
        flock($fp, LOCK_UN);
        fclose($fp);

        $decoded = json_decode($content, true);
        return $decoded ? $decoded : ['blocked' => false];
    } else {
        fclose($fp);
        return ['blocked' => false];
    }
}

function saveRoomAccess($data) {
    global $roomAccessFile;

    $tempFile = $roomAccessFile . '.tmp.' . uniqid();
    $content = json_encode($data);

    $fp = fopen($tempFile, 'w');
    if (!$fp) {
        return false;
    }

    if (flock($fp, LOCK_EX)) {
        $bytesWritten = fwrite($fp, $content);
        fflush($fp);
        flock($fp, LOCK_UN);
        fclose($fp);

        if ($bytesWritten === strlen($content)) {
            if (rename($tempFile, $roomAccessFile)) {
                return true;
            }
        }
    } else {
        fclose($fp);
    }

    if (file_exists($tempFile)) {
        unlink($tempFile);
    }
    return false;
}

function isRoomBlocked() {
    $roomData = loadRoomAccess();
    return $roomData['blocked'] ?? false;
}

// Appends one message under a single exclusive lock: read the last
// line to derive the next id, then write the new line at EOF. flock()
// blocks until the lock is free, so unlike the old retry/backoff loop
// this can't silently lose a message to a concurrent writer.
function appendMessage($user, $message, $type = 'text', $mimeType = null) {
    global $messagesFile;

    $fp = fopen($messagesFile, 'c+');
    if (!$fp) {
        return ['success' => false, 'error' => 'Unable to open messages file'];
    }

    if (!flock($fp, LOCK_EX)) {
        fclose($fp);
        return ['success' => false, 'error' => 'Unable to lock messages file'];
    }

    $newId = 1;
    $lastLine = getLastJsonLine($fp);
    if ($lastLine !== null) {
        $lastMessage = json_decode($lastLine, true);
        if (is_array($lastMessage) && isset($lastMessage['id'])) {
            $newId = $lastMessage['id'] + 1;
        }
    }

    $newMessage = [
        'id' => $newId,
        'user' => $user,
        'message' => $message,
        'type' => $type,
        'timestamp' => time()
    ];

    if ($mimeType) {
        $newMessage['mimeType'] = $mimeType;
    }

    $line = json_encode($newMessage) . "\n";

    fseek($fp, 0, SEEK_END);
    $bytesWritten = fwrite($fp, $line);
    fflush($fp);
    flock($fp, LOCK_UN);
    fclose($fp);

    if ($bytesWritten !== strlen($line)) {
        return ['success' => false, 'error' => 'Failed to write message'];
    }

    return ['success' => true, 'id' => $newId];
}

function addSystemMessage($message) {
    appendMessage('Sistema', $message, 'system');
}

// Lazy TTL prune (no cron), called once per addUser. Removes session
// tokens idle >24h from sessions.json, and cross-removes the same
// usernames from users.json -- otherwise a tab that outlives its token
// without ever firing beforeunload/pagehide (crash, OS-suspended mobile
// tab) leaves a permanent ghost entry in users.json, since a later
// removeUser beacon for that already-expired token can no longer
// resolve to a username. Skips a username still bound to another,
// non-expired session (same identity open in a second tab).
function pruneExpiredSessions($ttlSeconds = 86400) {
    global $currentDate;

    $sessions = loadSessions();
    $cutoff = time() - $ttlSeconds;
    $expiredUsers = [];
    $kept = [];

    foreach ($sessions as $hash => $s) {
        if (($s['lastSeen'] ?? 0) < $cutoff) {
            $expiredUsers[] = $s['user'];
        } else {
            $kept[$hash] = $s;
        }
    }

    if (count($kept) !== count($sessions)) {
        saveSessions($kept);
    }

    if (!empty($expiredUsers)) {
        $stillActive = array_column($kept, 'user');
        $toRemove = array_diff(array_unique($expiredUsers), $stillActive);
        if (!empty($toRemove)) {
            $users = array_values(array_diff(loadUsers(), $toRemove));
            saveUsers($users);
            foreach ($toRemove as $u) {
                addSystemMessage("$u has left the room");
            }
        }
    }

    return $kept;
}


$action = $_GET['action'] ?? $_POST['action'] ?? '';

switch ($action) {
    case 'addUser':
        $user = trim($_POST['user'] ?? '');
        $userToken = $_POST['userToken'] ?? '';

        if (!preg_match('/^[0-9a-f]{32}$/', $userToken)) {
            echo json_encode(['error' => 'Missing or invalid session token']);
            break;
        }

        $sessions = pruneExpiredSessions();
        $tokenHash = hash('sha256', $userToken);

        // Reconnect: token already bound to an identity (page refresh,
        // sessionStorage still holds it). The client-supplied $user is
        // ignored -- the server's existing binding wins. Deliberately
        // NOT gated by isRoomBlocked(): the lock is meant to stop new
        // participants from joining, not to kick an already-admitted
        // participant out just because they refreshed the tab.
        if (isset($sessions[$tokenHash]['user'])) {
            $boundUser = $sessions[$tokenHash]['user'];
            $sessions[$tokenHash]['lastSeen'] = time();
            saveSessions($sessions);

            $users = loadUsers();
            if (!in_array($boundUser, $users)) {
                $users[] = $boundUser;
                saveUsers($users);
            }

            echo json_encode(['success' => true, 'user' => $boundUser]);
            break;
        }

        // Same charset as the client-side check (validateUsername in
        // CORE/index.php): plain ASCII letters/digits/underscore only.
        // Rejecting anything else (instead of just stripping a few chars
        // and normalizing Unicode) blocks homoglyph usernames — e.g. a
        // Cyrillic "а" that visually impersonates "admin" without matching
        // it exactly in the reserved-name check below.
        if (!preg_match('/^[a-zA-Z0-9_]{3,20}$/', $user)) {
            echo json_encode(['error' => 'Username must contain only letters, numbers and underscore (min 3 max 20 characters).']);
            break;
        }

        if (strtolower($user) === 'admin' || strtolower($user) === 'system') {
            echo json_encode(['error' => 'Username not allowed. Please choose a different name.']);
            break;
        }

        $users = loadUsers();

        if (isRoomBlocked()) {
            echo json_encode(['error' => 'Room access is currently blocked. No new participants allowed.']);
            break;
        }

        $baseUser = $user;
        $suffix = 1;

        while (in_array($user, $users)) {
            $user = $baseUser . '_' . $suffix;
            $suffix++;
        }

        $users[] = $user;
        saveUsers($users);
        addSystemMessage("$currentDate: $user has joined the room");

        $sessions[$tokenHash] = ['user' => $user, 'lastSeen' => time()];
        saveSessions($sessions);

        echo json_encode(['success' => true, 'user' => $user]);
        break;

    case 'getUsers':
        echo json_encode(loadUsers());
        break;

    case 'sendMessage':
        $userToken = $_POST['userToken'] ?? '';
        $user = resolveUserFromToken($userToken);
        $message = $_POST['message'] ?? '';
        $command = $_POST['command'] ?? '';
        $postSessionPwd = $_POST['sessionPwd'] ?? '';
        $sessionPwd = preg_match('/^[0-9a-f]{32}$/', $postSessionPwd)
            ? $postSessionPwd
            : ($_SESSION['owned_rooms'][$roomId] ?? '');

        if (!$user) {
            echo json_encode(['error' => 'Session expired, please log in again', 'code' => 'session_expired']);
            break;
        }

        if ($user && $message) {
            if (in_array(strtolower($user), ['admin', 'system'], true)) {
                echo json_encode(['error' => 'Invalid user']);
                break;
            }
            if ($command === 'deleteall') {
                if (!verifyRoomOwnership($roomId, $sessionPwd)) {
                    echo json_encode(['error' => 'Only the room creator can use /deleteall']);
                    break;
                }
                $lockFile = 'chat.lock';
                $lockFp = fopen($lockFile, 'w');
                if (flock($lockFp, LOCK_EX)) {
                    // Load current messages and keep only the first 2 (welcome messages)
                    $currentMessages = loadMessages();
                    $welcomeMessages = array_slice($currentMessages, 0, 2);
                    writeAllMessages($welcomeMessages);
                    array_map('unlink', glob($audioDirectory . "*"));
                    array_map('unlink', glob($uploadDirectory . "*"));
                    addSystemMessage("The chat was deleted by $user");
                    flock($lockFp, LOCK_UN);
                    fclose($lockFp);
                    unlink($lockFile);
                }
                echo json_encode(['success' => true, 'action' => 'cleared']);
            } else {
                if (!isValidCiphertext($message)) {
                    echo json_encode(['error' => 'Invalid message format']);
                    break;
                }
                $result = appendMessage($user, $message, 'text');
                echo json_encode($result);
            }
        } else {
            echo json_encode(['error' => 'Missing user or message']);
        }
        break;

    case 'sendAudioMessage':
        $userToken = $_POST['userToken'] ?? '';
        $user = resolveUserFromToken($userToken);
        $encryptedContent = $_POST['encryptedAudio'] ?? '';
        $encryptedMeta = $_POST['encryptedMeta'] ?? '';
        $audioFileName = preg_replace('/[^a-zA-Z0-9_\-.]/', '', basename($_POST['audioFileName'] ?? ''));

        if (!$user) {
            echo json_encode(['error' => 'Session expired, please log in again', 'code' => 'session_expired']);
            break;
        }

        if (!preg_match('/^[a-zA-Z0-9_\-]+\.enc$/', $audioFileName)) {
            echo json_encode(['error' => 'Invalid audio file name format']);
            break;
        }

        if ($user && $encryptedContent && $encryptedMeta && $audioFileName) {
            $filePath = $audioDirectory . $audioFileName;
            if (file_put_contents($filePath, $encryptedContent) !== false) {
                $result = appendMessage($user, $encryptedMeta, 'audio');
                echo json_encode($result);
            } else {
                echo json_encode(['error' => 'Failed to save audio']);
            }
        } else {
            echo json_encode(['error' => 'Missing audio data']);
        }
        break;

    case 'getMessages':
        echo json_encode(loadMessages());
        break;

    case 'getNewMessages':
        $lastId = intval($_GET['lastId'] ?? 0);
        $messages = loadMessages();

        // Check if chat was reset (lastId > all message IDs means chat was cleared)
        $maxCurrentId = !empty($messages) ? max(array_column($messages, 'id')) : 0;

        // If lastId is greater than max current ID, chat was cleared - send all messages
        if ($lastId > $maxCurrentId && count($messages) > 0) {
            $newMessages = $messages;
        } else {
            // Normal case: filter messages after lastId
            $newMessages = array_filter($messages, function($msg) use ($lastId) {
                return $msg['id'] > $lastId;
            });
        }

        echo json_encode(array_values($newMessages));
        break;
        
    case 'sendFile':
        $userToken = $_POST['userToken'] ?? '';
        $user = resolveUserFromToken($userToken);
        $mimeType = $_POST['mimeType'] ?? 'application/octet-stream';
        $encryptedContent = $_POST['encryptedFile'] ?? '';
        $encryptedMeta = $_POST['encryptedMeta'] ?? '';
        $uploadFileName = preg_replace('/[^a-zA-Z0-9_\-.]/', '', basename($_POST['uploadFileName'] ?? ''));

        if (!$user) {
            echo json_encode(['error' => 'Session expired, please log in again', 'code' => 'session_expired']);
            break;
        }

        if (!preg_match('/^[a-zA-Z0-9_\-]+\.enc$/', $uploadFileName)) {
            echo json_encode(['error' => 'Invalid upload file name format']);
            break;
        }

        if ($user && $encryptedContent && $encryptedMeta && $uploadFileName) {
            $filePath = $uploadDirectory . $uploadFileName;
            if (file_put_contents($filePath, $encryptedContent) !== false) {
                $isImage = strpos($mimeType, 'image') === 0;
                $isVideo = strpos($mimeType, 'video') === 0;
                $type = $isImage ? 'image' : ($isVideo ? 'video' : 'file');
                $result = appendMessage($user, $encryptedMeta, $type, $mimeType);
                echo json_encode($result['success'] ? ['success' => true] : ['error' => 'Failed to save file message']);
            } else {
                echo json_encode(['error' => 'Failed to save file']);
            }
        } else {
            echo json_encode(['error' => 'Missing upload data']);
        }
        break;

    case 'setRoomAccess':
        $user = $_POST['user'] ?? '';
        $blocked = $_POST['blocked'] ?? 'false';
        $blocked = ($blocked === 'true' || $blocked === '1');
        $postSessionPwd = $_POST['sessionPwd'] ?? '';
        $sessionPwd = preg_match('/^[0-9a-f]{32}$/', $postSessionPwd)
            ? $postSessionPwd
            : ($_SESSION['owned_rooms'][$roomId] ?? '');

        if ($user) {
            if (!verifyRoomOwnership($roomId, $sessionPwd)) {
                echo json_encode(['error' => 'Only the room creator can change room access']);
                break;
            }

            $users = loadUsers();

            if (in_array($user, $users)) {
                $roomData = loadRoomAccess();
                $roomData['blocked'] = $blocked;
                $roomData['blocked_by'] = $user;
                $roomData['timestamp'] = time();
                saveRoomAccess($roomData);
                
                $statusMessage = $blocked ? "Room access blocked by $user" : "Room access unblocked by $user";
                addSystemMessage("$currentDate: $statusMessage");
                
                echo json_encode(['success' => true]);
            } else {
                echo json_encode(['error' => 'User not authorized']);
            }
        } else {
            echo json_encode(['error' => 'Missing user']);
        }
        break;
        
    case 'getRoomAccess':
        $roomData = loadRoomAccess();
        echo json_encode(['success' => true, 'blocked' => $roomData['blocked']]);
        break;

    case 'removeUser':
        // Called via navigator.sendBeacon on unload -- the response is
        // never read, so this always returns success even when the
        // token no longer resolves (already pruned); there's no client
        // left to react to an error.
        $userToken = $_POST['userToken'] ?? '';
        $user = resolveUserFromToken($userToken, false);
        if ($user) {
            $users = loadUsers();
            $index = array_search($user, $users);
            if ($index !== false) {
                array_splice($users, $index, 1);
                saveUsers($users);
                addSystemMessage("$user has left the room");
            }
            $sessions = loadSessions();
            $tokenHash = hash('sha256', $userToken);
            if (isset($sessions[$tokenHash])) {
                unset($sessions[$tokenHash]);
                saveSessions($sessions);
            }
        }
        echo json_encode(['success' => true]);
        break;

    default:
        echo json_encode(['error' => 'Invalid Action']);
}
?>